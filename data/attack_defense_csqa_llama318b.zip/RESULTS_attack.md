# Attacks and defenses: csqa / llama3.1:8b
G-Safeguard commit 890c99f1cb

## model
llama3.1:8b

## gsafeguard_commit
890c99f1cbc864e9ff0c85859619a14f42bc9cab

## training / original
160

## training / adaptive
96

## times / per_agent_fit_s
0.3332970142364502

## times / coordguard_features_s
2.0280911922454834

## times / coordguard_own_fit_s
0.468982458114624

## times / coordguard_group_fit_s
0.4917936325073242

## times / coordguard_full_fit_s
0.6222102642059326

## detection AUROC
| detector          |   diffuse |   diffuse [round 0] |   evasive (adaptive) |   evasive (adaptive) [round 0] |   format mimicry |   format mimicry [round 0] |   hard negatives |   held-out style |   held-out style [round 0] |   standard (authors) |   standard (authors) [round 0] |
|:------------------|----------:|--------------------:|---------------------:|-------------------------------:|-----------------:|---------------------------:|-----------------:|-----------------:|---------------------------:|---------------------:|-------------------------------:|
| G-Safeguard       |     0.773 |               0.664 |                0.659 |                          0.611 |            0.553 |                      0.498 |            0.981 |            0.997 |                      0.972 |                0.99  |                          0.884 |
| G-Safeguard (adv) |     0.808 |               0.714 |                0.749 |                          0.675 |            0.584 |                      0.545 |            0.969 |            0.994 |                      0.968 |                0.989 |                          0.889 |
| Per-agent         |     0.774 |               0.673 |                0.683 |                          0.643 |            0.552 |                      0.501 |            0.984 |            0.996 |                      0.974 |                0.991 |                          0.902 |
| Per-agent (adv)   |     0.79  |               0.702 |                0.735 |                          0.7   |            0.575 |                      0.528 |            0.976 |            0.997 |                      0.979 |                0.99  |                          0.892 |
| CoordGuard-own    |     0.719 |               0.693 |                0.715 |                          0.672 |            0.638 |                      0.555 |            0.999 |            1     |                      0.991 |                1     |                          0.943 |
| CoordGuard-group  |     0.789 |               0.721 |                0.791 |                          0.716 |            0.704 |                      0.629 |            0.999 |            1     |                      0.996 |                1     |                          0.96  |
| CoordGuard        |     0.932 |               0.75  |                0.906 |                          0.77  |            0.756 |                      0.659 |            0.998 |            1     |                      0.998 |                1     |                          0.983 |
| Outlier distance  |     0.814 |             nan     |                0.788 |                        nan     |            0.621 |                    nan     |            0.714 |            0.838 |                    nan     |                0.818 |                        nan     |

## detection (all metrics)
| condition                    | detector          |   AUROC | CI           |   recall@5%FPR |   recall@0.5 |   FPR@0.5 |   dissenter FPR@5% |
|:-----------------------------|:------------------|--------:|:-------------|---------------:|-------------:|----------:|-------------------:|
| standard (authors)           | G-Safeguard       |   0.99  | [0.98, 1.00] |          0.906 |        0.906 |     0.013 |            nan     |
| standard (authors)           | G-Safeguard (adv) |   0.989 | [0.98, 1.00] |          0.922 |        0.922 |     0.057 |            nan     |
| standard (authors)           | Per-agent         |   0.991 | [0.98, 1.00] |          0.972 |        0.961 |     0.037 |            nan     |
| standard (authors)           | Per-agent (adv)   |   0.99  | [0.98, 1.00] |          0.95  |        0.972 |     0.08  |            nan     |
| standard (authors)           | CoordGuard-own    |   1     | [1.00, 1.00] |          1     |        1     |     0.027 |            nan     |
| standard (authors)           | CoordGuard-group  |   1     | [1.00, 1.00] |          1     |        1     |     0.037 |            nan     |
| standard (authors)           | CoordGuard        |   1     | [1.00, 1.00] |          1     |        1     |     0.02  |            nan     |
| standard (authors)           | Outlier distance  |   0.818 | [0.76, 0.87] |          0.211 |        0.022 |     0     |            nan     |
| standard (authors) [round 0] | G-Safeguard       |   0.884 | [0.83, 0.93] |          0.578 |        0.578 |     0.047 |            nan     |
| standard (authors) [round 0] | G-Safeguard (adv) |   0.889 | [0.84, 0.93] |          0.544 |        0.744 |     0.123 |            nan     |
| standard (authors) [round 0] | Per-agent         |   0.902 | [0.85, 0.94] |          0.672 |        0.522 |     0.03  |            nan     |
| standard (authors) [round 0] | Per-agent (adv)   |   0.892 | [0.85, 0.93] |          0.567 |        0.65  |     0.07  |            nan     |
| standard (authors) [round 0] | CoordGuard-own    |   0.943 | [0.91, 0.97] |          0.817 |        0.85  |     0.073 |            nan     |
| standard (authors) [round 0] | CoordGuard-group  |   0.96  | [0.93, 0.98] |          0.817 |        0.883 |     0.083 |            nan     |
| standard (authors) [round 0] | CoordGuard        |   0.983 | [0.97, 0.99] |          0.872 |        0.928 |     0.07  |            nan     |
| held-out style               | G-Safeguard       |   0.997 | [0.99, 1.00] |          0.939 |        0.928 |     0.013 |            nan     |
| held-out style               | G-Safeguard (adv) |   0.994 | [0.99, 1.00] |          0.944 |        0.939 |     0.033 |            nan     |
| held-out style               | Per-agent         |   0.996 | [0.99, 1.00] |          0.983 |        0.983 |     0.047 |            nan     |
| held-out style               | Per-agent (adv)   |   0.997 | [0.99, 1.00] |          0.972 |        1     |     0.11  |            nan     |
| held-out style               | CoordGuard-own    |   1     | [1.00, 1.00] |          1     |        1     |     0.047 |            nan     |
| held-out style               | CoordGuard-group  |   1     | [1.00, 1.00] |          1     |        1     |     0.05  |            nan     |
| held-out style               | CoordGuard        |   1     | [1.00, 1.00] |          1     |        1     |     0.02  |            nan     |
| held-out style               | Outlier distance  |   0.838 | [0.79, 0.89] |          0.289 |        0     |     0     |            nan     |
| held-out style [round 0]     | G-Safeguard       |   0.972 | [0.95, 0.99] |          0.822 |        0.817 |     0.037 |            nan     |
| held-out style [round 0]     | G-Safeguard (adv) |   0.968 | [0.95, 0.98] |          0.833 |        0.9   |     0.087 |            nan     |
| held-out style [round 0]     | Per-agent         |   0.974 | [0.96, 0.99] |          0.928 |        0.839 |     0.047 |            nan     |
| held-out style [round 0]     | Per-agent (adv)   |   0.979 | [0.96, 0.99] |          0.872 |        0.95  |     0.083 |            nan     |
| held-out style [round 0]     | CoordGuard-own    |   0.991 | [0.98, 1.00] |          0.994 |        0.994 |     0.077 |            nan     |
| held-out style [round 0]     | CoordGuard-group  |   0.996 | [0.99, 1.00] |          0.989 |        0.989 |     0.083 |            nan     |
| held-out style [round 0]     | CoordGuard        |   0.998 | [0.99, 1.00] |          0.994 |        0.994 |     0.037 |            nan     |
| hard negatives               | G-Safeguard       |   0.981 | [0.96, 1.00] |          0.906 |        0.9   |     0.033 |              0.058 |
| hard negatives               | G-Safeguard (adv) |   0.969 | [0.93, 0.99] |          0.894 |        0.906 |     0.094 |              0.108 |
| hard negatives               | Per-agent         |   0.984 | [0.96, 1.00] |          0.944 |        0.961 |     0.072 |              0.067 |
| hard negatives               | Per-agent (adv)   |   0.976 | [0.96, 0.99] |          0.906 |        0.956 |     0.172 |              0.075 |
| hard negatives               | CoordGuard-own    |   0.999 | [1.00, 1.00] |          1     |        1     |     0.05  |              0.075 |
| hard negatives               | CoordGuard-group  |   0.999 | [1.00, 1.00] |          1     |        1     |     0.072 |              0.083 |
| hard negatives               | CoordGuard        |   0.998 | [0.99, 1.00] |          1     |        0.983 |     0.028 |              0.15  |
| hard negatives               | Outlier distance  |   0.714 | [0.68, 0.75] |          0.078 |        0.017 |     0     |              0.008 |
| format mimicry               | G-Safeguard       |   0.553 | [0.51, 0.60] |          0.006 |        0.006 |     0.017 |            nan     |
| format mimicry               | G-Safeguard (adv) |   0.584 | [0.54, 0.63] |          0.1   |        0.217 |     0.147 |            nan     |
| format mimicry               | Per-agent         |   0.552 | [0.52, 0.59] |          0.039 |        0.011 |     0.023 |            nan     |
| format mimicry               | Per-agent (adv)   |   0.575 | [0.54, 0.62] |          0.033 |        0.089 |     0.077 |            nan     |
| format mimicry               | CoordGuard-own    |   0.638 | [0.59, 0.69] |          0.139 |        0.089 |     0.033 |            nan     |
| format mimicry               | CoordGuard-group  |   0.704 | [0.65, 0.76] |          0.25  |        0.244 |     0.047 |            nan     |
| format mimicry               | CoordGuard        |   0.756 | [0.70, 0.82] |          0.356 |        0.461 |     0.107 |            nan     |
| format mimicry               | Outlier distance  |   0.621 | [0.57, 0.67] |          0.122 |        0     |     0     |            nan     |
| format mimicry [round 0]     | G-Safeguard       |   0.498 | [0.44, 0.56] |          0.028 |        0.028 |     0.063 |            nan     |
| format mimicry [round 0]     | G-Safeguard (adv) |   0.545 | [0.47, 0.61] |          0.078 |        0.306 |     0.217 |            nan     |
| format mimicry [round 0]     | Per-agent         |   0.501 | [0.44, 0.56] |          0.039 |        0.033 |     0.043 |            nan     |
| format mimicry [round 0]     | Per-agent (adv)   |   0.528 | [0.48, 0.59] |          0.033 |        0.067 |     0.087 |            nan     |
| format mimicry [round 0]     | CoordGuard-own    |   0.555 | [0.47, 0.62] |          0.094 |        0.133 |     0.067 |            nan     |
| format mimicry [round 0]     | CoordGuard-group  |   0.629 | [0.56, 0.71] |          0.122 |        0.267 |     0.127 |            nan     |
| format mimicry [round 0]     | CoordGuard        |   0.659 | [0.59, 0.74] |          0.122 |        0.333 |     0.183 |            nan     |
| diffuse                      | G-Safeguard       |   0.773 | [0.74, 0.80] |          0.328 |        0.311 |     0.02  |            nan     |
| diffuse                      | G-Safeguard (adv) |   0.808 | [0.77, 0.84] |          0.5   |        0.556 |     0.1   |            nan     |
| diffuse                      | Per-agent         |   0.774 | [0.75, 0.81] |          0.383 |        0.378 |     0.047 |            nan     |
| diffuse                      | Per-agent (adv)   |   0.79  | [0.76, 0.82] |          0.394 |        0.561 |     0.143 |            nan     |
| diffuse                      | CoordGuard-own    |   0.719 | [0.67, 0.78] |          0.317 |        0.322 |     0.057 |            nan     |
| diffuse                      | CoordGuard-group  |   0.789 | [0.75, 0.82] |          0.372 |        0.422 |     0.077 |            nan     |
| diffuse                      | CoordGuard        |   0.932 | [0.90, 0.96] |          0.728 |        0.656 |     0.037 |            nan     |
| diffuse                      | Outlier distance  |   0.814 | [0.78, 0.85] |          0.333 |        0     |     0     |            nan     |
| diffuse [round 0]            | G-Safeguard       |   0.664 | [0.62, 0.71] |          0.356 |        0.35  |     0.05  |            nan     |
| diffuse [round 0]            | G-Safeguard (adv) |   0.714 | [0.66, 0.76] |          0.394 |        0.483 |     0.127 |            nan     |
| diffuse [round 0]            | Per-agent         |   0.673 | [0.63, 0.72] |          0.361 |        0.35  |     0.047 |            nan     |
| diffuse [round 0]            | Per-agent (adv)   |   0.702 | [0.67, 0.74] |          0.367 |        0.411 |     0.083 |            nan     |
| diffuse [round 0]            | CoordGuard-own    |   0.693 | [0.65, 0.74] |          0.261 |        0.383 |     0.083 |            nan     |
| diffuse [round 0]            | CoordGuard-group  |   0.721 | [0.68, 0.77] |          0.306 |        0.389 |     0.083 |            nan     |
| diffuse [round 0]            | CoordGuard        |   0.75  | [0.70, 0.80] |          0.383 |        0.483 |     0.097 |            nan     |
| evasive (adaptive)           | G-Safeguard       |   0.659 | [0.61, 0.71] |          0.006 |        0.006 |     0.017 |            nan     |
| evasive (adaptive)           | G-Safeguard (adv) |   0.749 | [0.71, 0.79] |          0.3   |        0.461 |     0.127 |            nan     |
| evasive (adaptive)           | Per-agent         |   0.683 | [0.63, 0.74] |          0.05  |        0.033 |     0.043 |            nan     |
| evasive (adaptive)           | Per-agent (adv)   |   0.735 | [0.68, 0.79] |          0.111 |        0.289 |     0.113 |            nan     |
| evasive (adaptive)           | CoordGuard-own    |   0.715 | [0.67, 0.76] |          0.2   |        0.228 |     0.053 |            nan     |
| evasive (adaptive)           | CoordGuard-group  |   0.791 | [0.75, 0.83] |          0.361 |        0.394 |     0.073 |            nan     |
| evasive (adaptive)           | CoordGuard        |   0.906 | [0.87, 0.94] |          0.639 |        0.656 |     0.057 |            nan     |
| evasive (adaptive)           | Outlier distance  |   0.788 | [0.75, 0.82] |          0.283 |        0.011 |     0     |            nan     |
| evasive (adaptive) [round 0] | G-Safeguard       |   0.611 | [0.56, 0.66] |          0.15  |        0.15  |     0.053 |            nan     |
| evasive (adaptive) [round 0] | G-Safeguard (adv) |   0.675 | [0.62, 0.73] |          0.25  |        0.433 |     0.183 |            nan     |
| evasive (adaptive) [round 0] | Per-agent         |   0.643 | [0.58, 0.70] |          0.122 |        0.122 |     0.05  |            nan     |
| evasive (adaptive) [round 0] | Per-agent (adv)   |   0.7   | [0.65, 0.75] |          0.183 |        0.267 |     0.087 |            nan     |
| evasive (adaptive) [round 0] | CoordGuard-own    |   0.672 | [0.62, 0.72] |          0.2   |        0.294 |     0.093 |            nan     |
| evasive (adaptive) [round 0] | CoordGuard-group  |   0.716 | [0.67, 0.76] |          0.267 |        0.367 |     0.07  |            nan     |
| evasive (adaptive) [round 0] | CoordGuard        |   0.77  | [0.71, 0.82] |          0.367 |        0.483 |     0.09  |            nan     |

## graph_gain
|    | condition                    | comparison                           |   dAUROC |   dRecall@5%FPR |
|---:|:-----------------------------|:-------------------------------------|---------:|----------------:|
|  0 | standard (authors)           | G-Safeguard - Per-agent (paper)      |  -0.0009 |         -0.0667 |
|  1 | standard (authors)           | adv-trained: G-Safeguard - Per-agent |  -0.0009 |         -0.0278 |
|  2 | standard (authors)           | CoordGuard: + graph edges            |  -0.0002 |          0      |
|  3 | standard (authors)           | CoordGuard: + others' answers        |   0      |          0      |
|  4 | standard (authors) [round 0] | G-Safeguard - Per-agent (paper)      |  -0.0179 |         -0.0944 |
|  5 | standard (authors) [round 0] | adv-trained: G-Safeguard - Per-agent |  -0.003  |         -0.0222 |
|  6 | standard (authors) [round 0] | CoordGuard: + graph edges            |   0.0239 |          0.0556 |
|  7 | standard (authors) [round 0] | CoordGuard: + others' answers        |   0.016  |          0      |
|  8 | held-out style               | G-Safeguard - Per-agent (paper)      |   0.0003 |         -0.0444 |
|  9 | held-out style               | adv-trained: G-Safeguard - Per-agent |  -0.0029 |         -0.0278 |
| 10 | held-out style               | CoordGuard: + graph edges            |   0      |          0      |
| 11 | held-out style               | CoordGuard: + others' answers        |   0      |          0      |
| 12 | held-out style [round 0]     | G-Safeguard - Per-agent (paper)      |  -0.0029 |         -0.1056 |
| 13 | held-out style [round 0]     | adv-trained: G-Safeguard - Per-agent |  -0.0108 |         -0.0389 |
| 14 | held-out style [round 0]     | CoordGuard: + graph edges            |   0.0022 |          0.0056 |
| 15 | held-out style [round 0]     | CoordGuard: + others' answers        |   0.005  |         -0.0056 |
| 16 | hard negatives               | G-Safeguard - Per-agent (paper)      |  -0.003  |         -0.0389 |
| 17 | hard negatives               | adv-trained: G-Safeguard - Per-agent |  -0.007  |         -0.0111 |
| 18 | hard negatives               | CoordGuard: + graph edges            |  -0.0003 |          0      |
| 19 | hard negatives               | CoordGuard: + others' answers        |   0.0002 |          0      |
| 20 | format mimicry               | G-Safeguard - Per-agent (paper)      |   0.0008 |         -0.0333 |
| 21 | format mimicry               | adv-trained: G-Safeguard - Per-agent |   0.0088 |          0.0667 |
| 22 | format mimicry               | CoordGuard: + graph edges            |   0.0519 |          0.1056 |
| 23 | format mimicry               | CoordGuard: + others' answers        |   0.0662 |          0.1111 |
| 24 | format mimicry [round 0]     | G-Safeguard - Per-agent (paper)      |  -0.0022 |         -0.0111 |
| 25 | format mimicry [round 0]     | adv-trained: G-Safeguard - Per-agent |   0.0174 |          0.0444 |
| 26 | format mimicry [round 0]     | CoordGuard: + graph edges            |   0.03   |          0      |
| 27 | format mimicry [round 0]     | CoordGuard: + others' answers        |   0.0741 |          0.0278 |
| 28 | diffuse                      | G-Safeguard - Per-agent (paper)      |  -0.0016 |         -0.0556 |
| 29 | diffuse                      | adv-trained: G-Safeguard - Per-agent |   0.0179 |          0.1056 |
| 30 | diffuse                      | CoordGuard: + graph edges            |   0.1435 |          0.3556 |
| 31 | diffuse                      | CoordGuard: + others' answers        |   0.07   |          0.0556 |
| 32 | diffuse [round 0]            | G-Safeguard - Per-agent (paper)      |  -0.0086 |         -0.0056 |
| 33 | diffuse [round 0]            | adv-trained: G-Safeguard - Per-agent |   0.0121 |          0.0278 |
| 34 | diffuse [round 0]            | CoordGuard: + graph edges            |   0.029  |          0.0778 |
| 35 | diffuse [round 0]            | CoordGuard: + others' answers        |   0.0282 |          0.0444 |
| 36 | evasive (adaptive)           | G-Safeguard - Per-agent (paper)      |  -0.0244 |         -0.0444 |
| 37 | evasive (adaptive)           | adv-trained: G-Safeguard - Per-agent |   0.0146 |          0.1889 |
| 38 | evasive (adaptive)           | CoordGuard: + graph edges            |   0.1145 |          0.2778 |
| 39 | evasive (adaptive)           | CoordGuard: + others' answers        |   0.0759 |          0.1611 |
| 40 | evasive (adaptive) [round 0] | G-Safeguard - Per-agent (paper)      |  -0.0329 |          0.0278 |
| 41 | evasive (adaptive) [round 0] | adv-trained: G-Safeguard - Per-agent |  -0.0248 |          0.0667 |
| 42 | evasive (adaptive) [round 0] | CoordGuard: + graph edges            |   0.0532 |          0.1    |
| 43 | evasive (adaptive) [round 0] | CoordGuard: + others' answers        |   0.044  |          0.0667 |

## coordguard_importance
|             |   importance |
|:------------|-------------:|
| lr          |       0.173  |
| nbr_lr_in   |       0.0511 |
| echo        |       0.0312 |
| dev0        |       0.0263 |
| resist      |       0.0256 |
| msglen      |       0.02   |
| nbr_lr_out  |       0.0182 |
| coal        |       0.0106 |
| persist     |       0.0095 |
| indeg       |       0.0041 |
| changes     |       0.003  |
| outdeg      |       0.0021 |
| local_agree |       0.0021 |
| adopt_n     |       0.002  |
| adopt       |       0.0009 |
| mincoal     |       0.0006 |
| devt        |       0.0004 |
| tag         |      -0.0025 |

## attack_effect
| attack             |   dialogues |   wrong r0 |   wrong r1 |   wrong r2 |   wrong r3 |   MAS acc final |
|:-------------------|------------:|-----------:|-----------:|-----------:|-----------:|----------------:|
| standard (authors) |          60 |     0.2517 |     0.5058 |     0.6658 |     0.7942 |          0.15   |
| held-out style     |          60 |     0.2708 |     0.3417 |     0.5972 |     0.7528 |          0.1667 |
| format mimicry     |          60 |     0.2592 |     0.3486 |     0.4603 |     0.5428 |          0.3833 |
| diffuse            |          60 |     0.2592 |     0.33   |     0.5028 |     0.7006 |          0.25   |
| evasive (adaptive) |          60 |     0.2517 |     0.3428 |     0.5156 |     0.7425 |          0.2167 |

## evasion
|   round |   tries |   score_before |   score_after |
|--------:|--------:|---------------:|--------------:|
|       0 |  1.0615 |         0.3683 |        0.2475 |
|       1 |  1.0385 |         0.3391 |        0.2391 |
|       2 |  0.9231 |         0.2657 |        0.2489 |
|       3 |  0.8846 |         0.2574 |        0.2499 |

## e2e
|                |   wrong r0 |   wrong r1 |   wrong r2 |   wrong r3 |   MAS acc final |
|:---------------|-----------:|-----------:|-----------:|-----------:|----------------:|
| No defense     |     0.29   |     0.3133 |     0.505  |     0.7422 |          0.2333 |
| gsafeguard_adv |     0.2933 |     0.3556 |     0.3817 |     0.4733 |          0.5333 |
| no_graph_adv   |     0.2983 |     0.3733 |     0.4383 |     0.5517 |          0.4333 |
| coordguard     |     0.3067 |     0.3033 |     0.3383 |     0.4089 |          0.5333 |

## e2e_paired
| comparison                  | wrong final [95% CI]    | MAS acc [95% CI]        |
|:----------------------------|:------------------------|:------------------------|
| gsafeguard_adv - No defense | -0.269 [-0.458, -0.082] | +0.300 [+0.100, +0.500] |
| no_graph_adv - No defense   | -0.191 [-0.366, -0.008] | +0.200 [+0.000, +0.400] |
| coordguard - No defense     | -0.333 [-0.513, -0.153] | +0.300 [+0.100, +0.500] |
| coordguard - gsafeguard_adv | -0.064 [-0.213, +0.076] | +0.000 [-0.200, +0.200] |
| coordguard - no_graph_adv   | -0.143 [-0.283, -0.007] | +0.100 [-0.067, +0.267] |

## e2e_flags
|   round |   ('attackers flagged', 'coordguard') |   ('attackers flagged', 'gsafeguard_adv') |   ('attackers flagged', 'no_graph_adv') |   ('benign flagged', 'coordguard') |   ('benign flagged', 'gsafeguard_adv') |   ('benign flagged', 'no_graph_adv') |
|--------:|--------------------------------------:|------------------------------------------:|----------------------------------------:|-----------------------------------:|---------------------------------------:|-------------------------------------:|
|       0 |                                0.5222 |                                    0.4444 |                                  0.3111 |                             0.1067 |                                 0.2133 |                               0.1    |
|       1 |                                0.5222 |                                    0.4556 |                                  0.2444 |                             0.0333 |                                 0.1467 |                               0.0467 |
|       2 |                                0.5889 |                                    0.4556 |                                  0.2556 |                             0.0333 |                                 0.14   |                               0.0467 |
|       3 |                                0.6    |                                    0.4111 |                                  0.2444 |                             0.0333 |                                 0.1133 |                               0.0533 |

## operating_point
|                    |   wrong final |   MAS acc final |
|:-------------------|--------------:|----------------:|
| No defense         |        0.7933 |          0.1667 |
| G-Safeguard        |        0.4233 |          0.5    |
| No-graph (0.5)     |        0.435  |          0.5333 |
| No-graph (matched) |        0.4217 |          0.5    |

## operating_point_paired
| comparison                          | wrong [95% CI]          | MAS acc [95% CI]        |
|:------------------------------------|:------------------------|:------------------------|
| G-Safeguard - No-graph (matched)    | +0.002 [-0.075, +0.083] | +0.000 [-0.133, +0.133] |
| G-Safeguard - No-graph (0.5)        | -0.012 [-0.133, +0.113] | -0.033 [-0.200, +0.133] |
| No-graph (matched) - No-graph (0.5) | -0.013 [-0.158, +0.130] | -0.033 [-0.200, +0.133] |

## operating_point_threshold
0.3118822834321446

## hardware / hardware / gpu
Tesla T4, 15360 MiB, 580.178.04
Tesla T4, 15360 MiB, 580.178.04

## hardware / hardware / cpu
Intel(R) Xeon(R) CPU @ 2.00GHz

## hardware / hardware / cpu_cores
4

## hardware / hardware / torch
2.11.0+cu128

## hardware / latency
|    |   agents | density   | setting                   |    gs_ms |   gs_p95 |   lr_ms |   lr_p95 |
|---:|---------:|:----------|:--------------------------|---------:|---------:|--------:|---------:|
|  0 |        8 | real      | CPU 1 thread              |   5.5564 |   6.6028 |  0.0488 |   0.0686 |
|  1 |        8 | real      | CPU 4 threads             |   5.2862 |   6.3143 |  0.0743 |   0.1539 |
|  2 |        8 | real      | GPU                       |   2.6775 |   3.0382 |  0.175  |   0.2162 |
|  3 |        8 | real      | CPU 1 thread (CoordGuard) | nan      | nan      |  6.1143 |   6.7738 |
|  4 |        8 | 0.2       | CPU 1 thread              |   4.4247 |   5.3147 |  0.048  |   0.0675 |
|  5 |        8 | 0.2       | CPU 4 threads             |   3.3321 |   4.8869 |  0.0571 |   0.0828 |
|  6 |        8 | 0.2       | GPU                       |   2.4885 |   2.7211 |  0.1673 |   0.2062 |
|  7 |        8 | 1.0       | CPU 1 thread              |   6.2741 |   6.9453 |  0.0477 |   0.0644 |
|  8 |        8 | 1.0       | CPU 4 threads             |   5.8608 |   6.5408 |  0.0569 |   0.0835 |
|  9 |        8 | 1.0       | GPU                       |   2.706  |   4.9291 |  0.1668 |   0.2106 |
| 10 |       16 | 0.2       | CPU 1 thread              |   6.4314 |   6.9964 |  0.0603 |   0.0859 |
| 11 |       16 | 0.2       | CPU 4 threads             |   6.5029 |   7.0939 |  0.0762 |   0.101  |
| 12 |       16 | 0.2       | GPU                       |   2.7074 |   3.145  |  0.1876 |   0.2402 |
| 13 |       16 | 1.0       | CPU 1 thread              |  15.2241 |  17.0997 |  0.0612 |   0.0857 |
| 14 |       16 | 1.0       | CPU 4 threads             |  10.1949 |  11.0152 |  0.0779 |   0.1108 |
| 15 |       16 | 1.0       | GPU                       |   3.089  |   3.3017 |  0.1845 |   0.2231 |
| 16 |       32 | 0.2       | CPU 1 thread              |  14.1629 |  15.5169 |  0.0823 |   0.1094 |
| 17 |       32 | 0.2       | CPU 4 threads             |   9.8947 |  12.1769 |  0.1017 |   0.137  |
| 18 |       32 | 0.2       | GPU                       |   3.1778 |   3.3867 |  0.212  |   0.2572 |
| 19 |       32 | 1.0       | CPU 1 thread              |  51.4676 |  56.6353 |  0.0874 |   0.1221 |
| 20 |       32 | 1.0       | CPU 4 threads             |  28.6877 |  31.6392 |  0.0924 |   0.1232 |
| 21 |       32 | 1.0       | GPU                       |   4.9408 |   8.679  |  0.218  |   0.2681 |
| 22 |       64 | 0.2       | CPU 1 thread              |  44.9796 |  53.3107 |  0.1308 |   0.1662 |
| 23 |       64 | 0.2       | CPU 4 threads             |  25.1449 |  29.3725 |  0.1576 |   0.2023 |
| 24 |       64 | 0.2       | GPU                       |   4.7723 |   5.8681 |  0.2725 |   0.3115 |
| 25 |       64 | 1.0       | CPU 1 thread              | 306.206  | 323.753  |  0.1331 |   0.1659 |
| 26 |       64 | 1.0       | CPU 4 threads             | 163.343  | 175.63   |  0.1612 |   0.2032 |
| 27 |       64 | 1.0       | GPU                       |  14.2858 |  17.6379 |  0.2752 |   0.3382 |

## hardware / throughput
|    | detector    | device   |   batch |   dialogues_per_s |   agent_decisions_per_s |   ms_per_batch |   peak_gpu_mem_MB |   gpu_power_W |   J_per_1k_decisions |
|---:|:------------|:---------|--------:|------------------:|------------------------:|---------------:|------------------:|--------------:|---------------------:|
|  0 | G-Safeguard | CPU      |       1 |     287.872       |          2302.98        |         3.4738 |          nan      |      nan      |             nan      |
|  1 | Per-agent   | CPU      |       1 |   60150.7         |        481205           |         0.0166 |          nan      |      nan      |             nan      |
|  2 | G-Safeguard | GPU      |       1 |     540.619       |          4324.95        |         1.8497 |            0.2983 |       37.3167 |              -0.0983 |
|  3 | Per-agent   | GPU      |       1 |   23129.7         |        185038           |         0.0432 |            0.001  |       34.1227 |              -0.0196 |
|  4 | G-Safeguard | CPU      |       8 |     995.577       |          7964.62        |         8.0355 |          nan      |      nan      |             nan      |
|  5 | Per-agent   | CPU      |       8 |  239978           |             1.91982e+06 |         0.0333 |          nan      |      nan      |             nan      |
|  6 | G-Safeguard | GPU      |       8 |    3915.15        |         31321.2         |         2.0433 |            2.0103 |       41.1184 |               0.1078 |
|  7 | Per-agent   | GPU      |       8 |  192069           |             1.53655e+06 |         0.0417 |            0.001  |       34.7003 |              -0.002  |
|  8 | G-Safeguard | CPU      |      32 |    1069.71        |          8557.65        |        29.9148 |          nan      |      nan      |             nan      |
|  9 | Per-agent   | CPU      |      32 |  650388           |             5.20311e+06 |         0.0492 |          nan      |      nan      |             nan      |
| 10 | G-Safeguard | GPU      |      32 |   13933.7         |        111470           |         2.2966 |           15.145  |       60.3156 |               0.2025 |
| 11 | Per-agent   | GPU      |      32 |  714662           |             5.71729e+06 |         0.0448 |            0.002  |       43.5208 |               0.001  |
| 12 | G-Safeguard | CPU      |     128 |     573.624       |          4588.99        |       223.143  |          nan      |      nan      |             nan      |
| 13 | Per-agent   | CPU      |     128 |       1.31436e+06 |             1.05148e+07 |         0.0974 |          nan      |      nan      |             nan      |
| 14 | G-Safeguard | GPU      |     128 |   11534.2         |         92273.9         |        11.0974 |           87.6709 |       61.4919 |               0.2574 |
| 15 | Per-agent   | GPU      |     128 |       2.74082e+06 |             2.19266e+07 |         0.0467 |            0.0078 |       44.3531 |               0.0003 |
| 16 | G-Safeguard | CPU      |     512 |     525.202       |          4201.61        |       974.864  |          nan      |      nan      |             nan      |
| 17 | Per-agent   | CPU      |     512 |       1.35686e+06 |             1.08549e+07 |         0.3773 |          nan      |      nan      |             nan      |
| 18 | G-Safeguard | GPU      |     512 |   11978.2         |         95825.6         |        42.7443 |          356.956  |       61.8598 |               0.2517 |
| 19 | Per-agent   | GPU      |     512 |       1.03622e+07 |             8.28974e+07 |         0.0494 |            0.0312 |       63.1749 |               0.0003 |

## hardware / idle_power_W
37.74198019801981

## hardware / model_size / gs_params
4334593

## hardware / model_size / gs_MB_fp32
16.535160064697266

## hardware / model_size / lr_params
385

## hardware / embedding
|    | device   |   messages_per_call |   ms_per_call |   messages_per_s |
|---:|:---------|--------------------:|--------------:|-----------------:|
|  0 | cpu      |                   8 |      417.457  |          19.1637 |
|  1 | cpu      |                  64 |     3154.79   |          20.2866 |
|  2 | cpu      |                 512 |    26319      |          19.4537 |
|  3 | cuda     |                   8 |       24.1484 |         331.285  |
|  4 | cuda     |                  64 |      189.814  |         337.172  |
|  5 | cuda     |                 512 |     1658.15   |         308.778  |

## hardware / round_share / llm_round_ms
41587.590754032135

## hardware / round_share / embed_ms
24.14839400080382

## hardware / round_share / gs_ms
2.6774639991344884

## hardware / round_share / lr_ms
0.048769999921205454

## hardware / round_share / gs_share_pct
0.006433981819560933

## hardware / round_share / lr_share_pct
0.00011720236587111537

## hardware / gs_adv_time / features_s
285.55450773239136

## hardware / gs_adv_time / train_s
23.584747791290283

## hardware / gs_adv_time / dialogues
256

## hardware / gs_adv_time / gpu
True

## hardware / gs_orig_time / features_s
198.19816637039185

## hardware / gs_orig_time / train_s
18.173048734664917

## hardware / gs_orig_time / dialogues
160

## hardware / gs_orig_time / gpu
True

## hardware / fit_times / per_agent_fit_s
0.3332970142364502

## hardware / fit_times / coordguard_features_s
2.0280911922454834

## hardware / fit_times / coordguard_own_fit_s
0.468982458114624

## hardware / fit_times / coordguard_group_fit_s
0.4917936325073242

## hardware / fit_times / coordguard_full_fit_s
0.6222102642059326
