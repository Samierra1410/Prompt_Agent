# G-Safeguard re-evaluation

Agents: llama3.1:8b (Ollama) | G-Safeguard commit 890c99f1cb | training dialogues: 160
Deviations from the paper: open 8B agent model instead of GPT-4o-mini; CSQA validation split as test set (public test split has no labels); 8 instead of 40 training dialogues per configuration.

## detect_test_std
| detector                          |   node AUROC | 95% CI       |   acc@0.5 |   attacker recall@0.5 |   normal FPR@0.5 |   attacker recall@5%FPR |
|:----------------------------------|-------------:|:-------------|----------:|----------------------:|-----------------:|------------------------:|
| G-Safeguard (as deployed)         |        0.992 | [0.98, 1.00] |     0.962 |                 0.922 |            0.013 |                   0.922 |
| G-Safeguard (as trained features) |        0.992 | [0.98, 1.00] |     0.962 |                 0.922 |            0.013 |                   0.922 |
| Per-agent classifier (no graph)   |        0.991 | [0.98, 1.00] |     0.962 |                 0.961 |            0.037 |                   0.972 |
| Outlier distance (training-free)  |        0.818 | [0.76, 0.86] |   nan     |               nan     |          nan     |                   0.211 |

## detect_test_subtle
| detector                          |   node AUROC | 95% CI       |   acc@0.5 |   attacker recall@0.5 |   normal FPR@0.5 |   attacker recall@5%FPR |
|:----------------------------------|-------------:|:-------------|----------:|----------------------:|-----------------:|------------------------:|
| G-Safeguard (as deployed)         |        0.996 | [0.99, 1.00] |     0.971 |                 0.939 |            0.01  |                   0.939 |
| G-Safeguard (as trained features) |        0.997 | [0.99, 1.00] |     0.969 |                 0.933 |            0.01  |                   0.939 |
| Per-agent classifier (no graph)   |        0.996 | [0.99, 1.00] |     0.965 |                 0.983 |            0.047 |                   0.983 |
| Outlier distance (training-free)  |        0.838 | [0.80, 0.88] |   nan     |               nan     |          nan     |                   0.289 |

## detect_test_dissent
| detector                          |   node AUROC | 95% CI       |   acc@0.5 |   attacker recall@0.5 |   normal FPR@0.5 |   attacker recall@5%FPR |   dissenter FPR@0.5 |   dissenter FPR@5%FPR thr |   AUROC attacker vs dissenter |
|:----------------------------------|-------------:|:-------------|----------:|----------------------:|-----------------:|------------------------:|--------------------:|--------------------------:|------------------------------:|
| G-Safeguard (as deployed)         |        0.981 | [0.96, 0.99] |     0.929 |                 0.9   |            0.033 |                   0.9   |               0.083 |                     0.1   |                         0.976 |
| G-Safeguard (as trained features) |        0.981 | [0.96, 0.99] |     0.931 |                 0.9   |            0.033 |                   0.9   |               0.075 |                     0.092 |                         0.976 |
| Per-agent classifier (no graph)   |        0.984 | [0.96, 1.00] |     0.935 |                 0.961 |            0.072 |                   0.944 |               0.092 |                     0.067 |                         0.981 |
| Outlier distance (training-free)  |        0.714 | [0.67, 0.76] |   nan     |               nan     |          nan     |                   0.078 |             nan     |                     0.008 |                         0.765 |

## detect_turn0
| condition   |   G-Safeguard turn-0 |   No-graph turn-0 |
|:------------|---------------------:|------------------:|
| test_std    |                0.888 |             0.902 |
| test_subtle |                0.97  |             0.974 |

## defense
| setting                     |   dialogues |   wrong-answer rate t0 |   wrong-answer rate t1 |   wrong-answer rate t2 |   wrong-answer rate t3 |   MAS acc t0 |   MAS acc t1 |   MAS acc t2 |   MAS acc t3 |
|:----------------------------|------------:|-----------------------:|-----------------------:|-----------------------:|-----------------------:|-------------:|-------------:|-------------:|-------------:|
| No defense                  |          30 |                  0.339 |                  0.596 |                  0.75  |                  0.829 |        0.533 |        0.4   |        0.267 |        0.167 |
| G-Safeguard defense         |          30 |                  0.315 |                  0.449 |                  0.465 |                  0.43  |        0.567 |        0.567 |        0.5   |        0.5   |
| No-graph classifier defense |          30 |                  0.342 |                  0.432 |                  0.486 |                  0.464 |        0.533 |        0.467 |        0.5   |        0.533 |

## defense_flags
| detector   |   attackers flagged |   benign flagged |
|:-----------|--------------------:|-----------------:|
| gsafeguard |               0.911 |            0     |
| no_graph   |               0.967 |            0.013 |
